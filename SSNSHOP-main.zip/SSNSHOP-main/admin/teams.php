
<?php
include('header.php');
$home=0;
include('../admin/template/_header.php');

?>



<?php 

/* include _footer.php */ 
include("../template/_footer.php");
/* !include _footer.php */ 

/* include footer.php */ 
include("../footer.php");
/* !include footer.php */ 

?>