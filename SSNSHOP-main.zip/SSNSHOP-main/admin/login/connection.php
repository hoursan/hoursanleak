<?php 
$conn = mysqli_connect('localhost', 'root', '', 'ssnshop');
// $conn = mysqli_connect('sql108.epizy.com', 'epiz_31168149', 'Dxxq9k8hyBFQ', 'epiz_31168149_ssnshop');
?>