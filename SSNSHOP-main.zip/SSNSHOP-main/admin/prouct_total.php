<?php
include('header.php');
$home=0;
include('../admin/template/_header.php');
include('../admin/template/_product_total.php');


?>


<?php
include('../footer.php');
?>


<div style="height: 200px;">
</div>