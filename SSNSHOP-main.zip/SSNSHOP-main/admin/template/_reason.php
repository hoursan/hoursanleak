        <!-- Menu -->
        <div id="reason" class="modal fade">
            <div class="modal-dialog">
              <div class="modal-content">
                
                <div class="menu-header">
                  <a href="./index.php"><img src="../assets/logos/ssnshop.gif" class="logo"></a>          
                    <button type="button" class="close pr-2 pt-1" data-dismiss="modal"><i class="material-icons">close</i></button>    
                </div>



          <div class="container">
              <div class="card" style="width: 18rem;">
                <img src="https://gadgetworld254.co.ke/wp-content/uploads/2021/10/iphone-13-pro-max-blue-256gb-in-Kenya-866x1024.png" class="card-img-top col-5 " alt="...">
                  <div class="ml-3">
                    <b class="card-text">Order ID : 001</b><br>
                    <b class="card-text">User ID : 001</b><br>
                    <b class="card-text">Iphone 13 Pro Max</b>
                  </div>
                <div class="card-body">
                
                  <h5 class="card-title">Reason</h5>
                  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea><br>

                  <a href="#" class="btn btn-primary">Send</a>
                </div>
              </div>
          </div>

          

<br>


              </div>
            </div>
          </div>
        <!-- End Modal HTML -->