
<div id="not_found" style="text-align: center;">
<img src="./../assets//404.svg" alt="" style="width: 300px;">
    <div class="wrapper">
        <br>
        <h4>Product "<?= $_GET['pro_detail']?? " " ; ?>" Not Found</h4>
    
       <!-- Copyright -->
  <div class="text-center p-4">
    © 2021 Copyright :
    <a class="text-reset fw-bold" href="http://ssnshop.epizy.com"> SSN Electronic Shop</a>
  </div>
  <!-- Copyright -->
    </div>
</div>