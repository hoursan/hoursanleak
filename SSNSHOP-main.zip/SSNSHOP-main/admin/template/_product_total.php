
             
             <!-- Begin Page Content -->
                <div class="container-fluid">
                    <br>
                    <!-- Content Row -->
                    <div class="row">

                        
                    <?php 
                    
                        foreach ($pro_total as $row){
                        include('../admin/template/_product.php');
                                
                        }

                    ?>

                        
                    </div>
                </div>  

                

