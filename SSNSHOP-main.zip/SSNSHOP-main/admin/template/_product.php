
                        
 <?php 
	
    include('./template/_delete_product.php');
    include('../admin/template/card/card_product.php');


?>


