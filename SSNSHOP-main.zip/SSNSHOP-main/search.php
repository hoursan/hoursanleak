<?php 

/* include _header.php */ 
include("./header.php");
/* !include _header.php */ 

//Require brand-carousel-top Class
require('./backend/product.php');

include './template/_header-search.php';


?>
 

<?php

include './template/_product.php';

?>



<?php 

    //Include footer.php file
    include("footer.php");

 ?>            









    
  </body>
</html>