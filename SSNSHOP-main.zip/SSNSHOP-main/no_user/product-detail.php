<?php 
    //Include header.php file
    $home=0;
    include("header.php");

 ?>


<?php 
    //Include header.php file
    include("_product-detail.php");

 ?>
<div style="height: 200px;">

</div>
<?php 
    
    //Include footer.php file
    include("../footer.php");

 ?>