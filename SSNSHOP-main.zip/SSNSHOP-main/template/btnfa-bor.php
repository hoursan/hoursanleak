                        <a href="#addfa<?php echo $row['pro_id']; ?>" data-toggle="modal" class="add-fa icon_favorite">
                            <i class="material-icons color-item" style="font-size: 26px;" >favorite_border</i>
						</a>